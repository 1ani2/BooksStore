About the application:
-----------------------

1. Attached is an node js BookStore application.
2. The api endpoints for the app is developed using express js.
3. Assumption : A Sample database is hardcoded using array of objects in json format.
4. On starting the app using command node app.js, in postman, the user can
use Get() to check all the books present in the sample database.
use Get(id) to search a specific book using it's id.
use Post() to add new books to the sample database.
use Put(id) to modify information related to the specific book by passing it's id.
use Delete(id) to delete a book from the sample database by passing it's id.
